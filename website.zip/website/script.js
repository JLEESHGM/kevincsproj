var totalScore = 0;

function addScore() {
  var input = document.getElementById('input').value;
  if (input == 'A') {
      totalScore += 1;
  }
  else {
    totalScore -= 1;
  }
  document.getElementById('score').innerHTML = totalScore;
}
